package com.fizi.qrisvoice;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.speech.tts.TextToSpeech;
import android.util.Log;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class QrisNotificationListener extends NotificationListenerService {
    private static final String TAG = "QRIS_VOICE";
    private TextToSpeech tts;
    private String lastSpoken = "";
    private long lastTime = 0;

    @Override
    public void onCreate() {
        super.onCreate();
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                tts.setLanguage(new Locale("id", "ID"));
                tts.setSpeechRate(0.95f);
            }
        });
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null || tts == null) return;

        String pkg = sbn.getPackageName();
        // DANA Android package. Keep a fallback keyword check below in case the package changes.
        if (!"id.dana".equals(pkg)) return;

        Notification n = sbn.getNotification();
        Bundle e = n.extras;
        if (e == null) return;

        String title = String.valueOf(e.getCharSequence(Notification.EXTRA_TITLE, ""));
        String text = String.valueOf(e.getCharSequence(Notification.EXTRA_TEXT, ""));
        String big = String.valueOf(e.getCharSequence(Notification.EXTRA_BIG_TEXT, ""));

        String raw = (title + " " + text + " " + big).trim();
        if (raw.isEmpty()) return;

        String lower = raw.toLowerCase(Locale.ROOT);

        // Only react to likely incoming/payment notifications.
        boolean payment =
                lower.contains("pembayaran") ||
                lower.contains("diterima") ||
                lower.contains("qris") ||
                lower.contains("masuk") ||
                lower.contains("receive") ||
                lower.contains("received");

        if (!payment) return;

        // Ignore notifications that look like outgoing payments.
        if (lower.contains("kamu membayar") || lower.contains("pembayaran berhasil ke")) return;

        long now = System.currentTimeMillis();
        if (raw.equals(lastSpoken) && now - lastTime < 15000) return;
        lastSpoken = raw;
        lastTime = now;

        String spoken = makeSpeech(raw);
        Log.d(TAG, "Incoming: " + raw);
        Log.d(TAG, "Speech: " + spoken);

        tts.speak(spoken, TextToSpeech.QUEUE_FLUSH, null, "qris_payment");
    }

    private String makeSpeech(String raw) {
        // Clean common notification formatting while preserving the useful information.
        String s = raw.replaceAll("\s+", " ").trim();

        // Convert Rp / IDR amounts to a more natural spoken form.
        s = s.replaceAll("(?i)Rp\.?\s*([0-9][0-9.,]*)", "rupiah $1");
        s = s.replaceAll("(?i)IDR\s*([0-9][0-9.,]*)", "rupiah $1");

        // The first version deliberately reads the actual DANA notification.
        // This avoids guessing a payer's name when DANA formats notifications differently.
        return "Pembayaran QRIS masuk. " + s;
    }

    @Override
    public void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }
}
